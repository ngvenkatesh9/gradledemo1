package com.demo;

public class App {
	public String test() {
		return "Successfull";
	}
}
